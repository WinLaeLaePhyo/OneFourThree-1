﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using OneFourThree.App_Code;

namespace OneFourThree.Controllers
{
    public class LoverController : Controller
    {
        // GET: Lover
        #region Declaration
        DBBack db = new DBBack();
        ParameterBack p = new ParameterBack();
        public ActionResult Dashboard()
        {
            return View();
        }
        public int GetCurrentUserID()
        {
            return Convert.ToInt32(Session["CurrentUserID"]);
        }
        #endregion

        #region SearchOnMap
        public ActionResult SearchOnMap()
        {
            if (TempData["Gender"] != null && TempData["Age"] != null)
            {
                ViewBag.Gender = TempData["Gender"].ToString();
                ViewBag.Age = TempData["Age"];
            }
            else
            {
                int Age = 21;
                //int Age = db.getIntByQuery("select * form Lover where ID=" + GetCurrentUserID(), "Age");
                ViewBag.Gender = "Male";
                ViewBag.Age = Age;
            }
            return View();
        }
        public ActionResult ProcessSearchOnMap()
        {
            string Gender = Request.Form["Gender"];
            int Age = Convert.ToInt32(Request.Form["Age"]);
            TempData["Gender"] = Gender;
            TempData["Age"] = Age;
            return RedirectToAction("SearchOnMap");
        }
        #endregion

        #region Get Lover JSON GET
        public JsonResult GetLover()
        {
            var data = new List<ElementDataList>();
            try
            {
                ElementDataList mg = new ElementDataList();
                double sLatitude = Convert.ToDouble(Request.QueryString["Lat"]);
                double sLongitude = Convert.ToDouble(Request.QueryString["Lng"]);
                string Gender = Request.QueryString["Gender"];
                int Age = Convert.ToInt32(Request.QueryString["Age"]);
                data = mg.GetLover(sLatitude, sLongitude, Gender, Age);
                return Json(data, JsonRequestBehavior.AllowGet);
            }
            catch { return Json(data, JsonRequestBehavior.AllowGet); }
        }
        #endregion
    }
}
